import streamlit as st
from backend.schemas import CityDTO
from frontend.components import add_item_to_cart, navigate_to, render_product_card
from services.product_service import get_categories, get_product_detail, list_products_for_city
from utils.config import settings
from utils.helpers import format_inr, get_offline_fallback_png, get_product_photo_url


def render_home_page(city: CityDTO) -> None:
    s_col1, s_col2 = st.columns([5, 1.2], vertical_alignment="bottom")
    with s_col1:
        query = st.text_input(
            "Search BharatKart",
            value=st.session_state.global_search,
            placeholder=f"Search artisan homeware, electronics, single-estate coffee in {city.name}...",
            label_visibility="collapsed",
        )
    with s_col2:
        if st.button("Search", type="primary", use_container_width=True, key="home_search_btn"):
            st.session_state.global_search = query
            navigate_to("Catalogue")

    st.markdown(
        f"""
        <div class="bk-hero">
            <div class="bk-hero-eyebrow">Hyperlocal Fulfillment · {city.label}</div>
            <div class="bk-hero-title">Crafted Goods, Delivered From Your City.</div>
            <div class="bk-hero-desc">
                Discover heirloom brassware, specialty Malnad roasts, handloom silks, and everyday essentials—with
                real-time warehouse stock verified exclusively for <strong>{city.name}</strong>.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.subheader("Shop by Department")
    categories = get_categories()
    cat_cols = st.columns(len(categories))
    for idx, cat in enumerate(categories):
        with cat_cols[idx]:
            if st.button(cat, key=f"home_cat_{cat}", use_container_width=True):
                st.session_state.global_search = ""
                navigate_to("Catalogue", category=cat)

    st.markdown("<div style='height: 1.2rem;'></div>", unsafe_allow_html=True)

    st.subheader(f"Featured in {city.name}")
    featured = list_products_for_city(city_id=city.id, only_featured=True)
    if featured:
        cols = st.columns(4)
        for idx, prod in enumerate(featured[:4]):
            with cols[idx % 4]:
                render_product_card(prod, key_prefix="home_feat")

    st.markdown("<div style='height: 1.2rem;'></div>", unsafe_allow_html=True)

    h_left, h_right = st.columns([4, 1.3], vertical_alignment="center")
    with h_left:
        st.subheader("Popular Across India")
    with h_right:
        if st.button("Explore Full Catalogue →", use_container_width=True, key="home_view_all"):
            navigate_to("Catalogue", category="All")

    popular = list_products_for_city(city_id=city.id, sort_by="Top Rated")
    pop_cols = st.columns(4)
    for idx, prod in enumerate(popular[:8]):
        with pop_cols[idx % 4]:
            render_product_card(prod, key_prefix="home_pop")


def render_catalogue_page(city: CityDTO) -> None:
    st.title(f"Catalogue — {city.label}")

    categories = ["All"] + get_categories()
    if st.session_state.selected_category not in categories:
        st.session_state.selected_category = "All"

    f1, f2, f3, f4 = st.columns([2.6, 1.5, 1.5, 1.2], vertical_alignment="bottom")
    with f1:
        search_input = st.text_input(
            "Search products, brands, or descriptions",
            value=st.session_state.global_search,
            placeholder="e.g., Earbuds, Brass, Coffee, Sandalwood...",
        )
        st.session_state.global_search = search_input
    with f2:
        chosen_cat = st.selectbox(
            "Category",
            options=categories,
            index=categories.index(st.session_state.selected_category),
        )
        st.session_state.selected_category = chosen_cat
    with f3:
        sort_by = st.selectbox(
            "Sort By",
            options=["Featured", "Price: Low to High", "Price: High to Low", "Top Rated", "Availability"],
        )
    with f4:
        in_stock_only = st.checkbox("In Stock Only", value=False)

    products = list_products_for_city(
        city_id=city.id,
        search_query=search_input,
        category=chosen_cat,
        sort_by=sort_by,
        in_stock_only=in_stock_only,
    )

    st.caption(f"Showing {len(products)} product(s) available for dispatch in {city.label}")

    if not products:
        st.markdown(
            """
            <div class="bk-panel" style="text-align: center; padding: 2.5rem;">
                <h3>No matching products found</h3>
                <p style="color: #59524B;">Try clearing your search filters or exploring another department.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        if st.button("Reset Filters", type="primary"):
            st.session_state.global_search = ""
            st.session_state.selected_category = "All"
            st.rerun()
        return

    cols = st.columns(4)
    for idx, prod in enumerate(products):
        with cols[idx % 4]:
            render_product_card(prod, key_prefix="cat")


def render_product_details_page(city: CityDTO) -> None:
    if st.button("← Back to Catalogue"):
        navigate_to("Catalogue")

    pid = st.session_state.selected_product_id
    if not pid:
        st.info("Select a product from the catalogue to view details.")
        return

    product = get_product_detail(product_id=pid, city_id=city.id)
    if not product:
        st.error("Product not found for the selected city.")
        return

    left, right = st.columns([1.15, 1.35], gap="large")
    fallback_uri = get_offline_fallback_png(product.sku, product.category)

    with left:
        st.markdown(
            f"""
            <div class="bk-panel" style="padding: 0.8rem;">
                <img src="{get_product_photo_url(product.sku) if product.sku == 'BK-HOM-005' else product.image_url}"
                     onerror="this.onerror=null; this.src='{fallback_uri}';"
                     alt="{product.name}"
                     style="width: 100%; height: 410px; object-fit: cover; border-radius: 8px;"/>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with right:
        st.markdown(
            f'<div class="bk-card-brand">{product.category} · {product.brand} · SKU: {product.sku}</div>',
            unsafe_allow_html=True,
        )
        st.title(product.name)
        st.markdown(f"**Customer Rating:** ★ {product.rating} / 5.00")

        discount_tag = (
            f'<span class="bk-discount">Save {product.discount_percent}%</span>'
            if product.discount_percent > 0
            else ""
        )
        st.markdown(
            f"""
            <div class="bk-price-row" style="margin: 1rem 0;">
                <span class="bk-price" style="font-size: 1.65rem;">{format_inr(product.price)}</span>
                <span class="bk-mrp" style="font-size: 1.05rem;">{format_inr(product.mrp)}</span>
                {discount_tag}
            </div>
            """,
            unsafe_allow_html=True,
        )

        if product.stock_quantity > settings.LOW_STOCK_THRESHOLD:
            stock_msg = f"<span class='bk-stock-ok'>{product.stock_quantity} units ready to ship</span>"
        elif product.stock_quantity > 0:
            stock_msg = f"<span class='bk-stock-low'>Only {product.stock_quantity} left!</span>"
        else:
            stock_msg = f"<span class='bk-stock-out'>Currently Out of Stock in {product.city_name}</span>"

        st.markdown(
            f"""
            <div class="bk-panel">
                <div style="margin-bottom: 0.4rem;"><strong>Fulfillment Hub:</strong> {product.city_name}</div>
                <div><strong>Live Warehouse Availability:</strong> {stock_msg}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.write(product.description)
        st.markdown("<div style='height: 0.6rem;'></div>", unsafe_allow_html=True)

        if product.stock_quantity > 0:
            already_in_cart = st.session_state.cart.get(product.id, 0)
            max_addable = max(0, product.stock_quantity - already_in_cart)

            if max_addable == 0:
                st.warning(f"You already have all {product.stock_quantity} available units in your cart.")
                if st.button("Go to Cart", type="primary"):
                    navigate_to("Cart")
            else:
                q_col, b_col = st.columns([1, 2], vertical_alignment="bottom")
                with q_col:
                    qty = st.number_input(
                        "Quantity",
                        min_value=1,
                        max_value=max_addable,
                        value=1,
                        step=1,
                        key=f"pdp_qty_{product.id}",
                    )
                with b_col:
                    if st.button("Add to Shopping Bag", type="primary", use_container_width=True):
                        add_item_to_cart(product, int(qty))
                        st.rerun()
        else:
            st.button("Out of Stock in Selected City", disabled=True, use_container_width=True)
