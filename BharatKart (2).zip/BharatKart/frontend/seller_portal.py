import pandas as pd
from pydantic import ValidationError
import streamlit as st
from backend.schemas import (
    CityDTO,
    CustomerRegistrationRequest,
    ShopRegistrationRequest,
)
from frontend.components import navigate_to
from services.customer_service import (
    CustomerRegistrationError,
    register_or_update_customer,
)
from services.product_service import get_active_cities, get_categories
from services.shop_service import (
    ShopRegistrationError,
    list_registered_shops,
    register_shop_atomic,
)


def render_customer_registration_page(current_city: CityDTO) -> None:
    if st.button("← Back to Storefront"):
        navigate_to("Home")

    st.markdown(
        """
        <div class="bk-hero" style="padding: 1.9rem 2.4rem;">
            <div class="bk-hero-eyebrow">BharatKart Buyer Membership</div>
            <div class="bk-hero-title" style="font-size: 2rem;">Create Your Buyer Profile</div>
            <div class="bk-hero-desc">
                Register once to save your default fulfillment city, shipping address, and mobile number—auto-filling
                your details during checkout.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    existing_cust = st.session_state.get("registered_customer")
    if existing_cust:
        st.success(
            f"**Active Buyer Profile:** {existing_cust.full_name} ({existing_cust.email}) · "
            f"Default Hub: **{existing_cust.city_name}** ({existing_cust.pincode})."
        )

    cities = get_active_cities()
    city_by_id = {c.id: c for c in cities}
    city_ids = [c.id for c in cities]
    default_idx = (
        city_ids.index(existing_cust.default_city_id)
        if existing_cust and existing_cust.default_city_id in city_ids
        else city_ids.index(current_city.id)
    )

    with st.form("customer_self_reg_form"):
        st.markdown('<div class="bk-step-badge">Buyer Self-Registration Details</div>', unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            full_name = st.text_input(
                "Full Name *",
                value=existing_cust.full_name if existing_cust else "",
                placeholder="e.g., Aarav Sharma",
            )
            email = st.text_input(
                "Email Address *",
                value=existing_cust.email if existing_cust else "",
                placeholder="aarav.sharma@example.com",
            )
        with c2:
            phone = st.text_input(
                "Mobile Number (10-digit) *",
                value=existing_cust.phone if existing_cust else "",
                placeholder="9876543210",
            )
            default_city_id = st.selectbox(
                "Preferred Delivery City *",
                options=city_ids,
                index=default_idx,
                format_func=lambda cid: city_by_id[cid].label,
            )

        a1, a2 = st.columns([2.5, 1])
        with a1:
            default_address = st.text_area(
                "Default Shipping Address *",
                value=existing_cust.default_address if existing_cust else "",
                placeholder="Flat 402, Heritage Residency, Indiranagar 2nd Stage",
                height=80,
            )
        with a2:
            pincode = st.text_input(
                "Pincode *",
                max_chars=6,
                value=existing_cust.pincode if existing_cust else "",
                placeholder="560038",
            )

        submitted = st.form_submit_button("Save Buyer Profile", type="primary", use_container_width=True)

    if submitted:
        try:
            req = CustomerRegistrationRequest(
                full_name=full_name,
                email=email,
                phone=phone,
                default_city_id=default_city_id,
                default_address=default_address,
                pincode=pincode,
            )
            cust_dto = register_or_update_customer(req)
            st.session_state.registered_customer = cust_dto
            if not st.session_state.cart:
                st.session_state.selected_city_id = cust_dto.default_city_id
            st.toast(f"Welcome to BharatKart, {cust_dto.full_name}!", icon="✅")
            st.rerun()
        except ValidationError as ve:
            for err in ve.errors():
                field = str(err["loc"][-1]).replace("_", " ").title() if err.get("loc") else "Field"
                st.error(f"**{field}**: {err['msg']}")
        except CustomerRegistrationError as cre:
            st.error(str(cre))


def render_shop_registration_page(current_city: CityDTO) -> None:
    if st.button("← Back to Storefront"):
        navigate_to("Home")

    st.markdown(
        """
        <div class="bk-hero" style="padding: 1.9rem 2.4rem;">
            <div class="bk-hero-eyebrow">BharatKart Seller Hub · Dedicated Onboarding Page</div>
            <div class="bk-hero-title" style="font-size: 2.05rem;">Register Your Shop on BharatKart</div>
            <div class="bk-hero-desc">
                Reach verified buyers across Bengaluru, Mumbai, Pune, and Mangalore.
                Submit your business KYC, tax credentials, pickup address, and bank settlement details below.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    tab_register, tab_directory, tab_guide = st.tabs(
        ["New Shop Registration Form", "Verified Partner Shops Directory", "Documents & Commission Guide"]
    )

    with tab_register:
        if st.session_state.get("last_registered_shop"):
            shop = st.session_state.last_registered_shop
            st.success(
                f"**Shop Registered Successfully!** Your Partner Shop ID is **`{shop.shop_code}`** "
                f"for **{shop.shop_name}** ({shop.city_name}). Status: **{shop.status}**."
            )

        cities = get_active_cities()
        city_by_id = {c.id: c for c in cities}
        city_ids = [c.id for c in cities]
        default_city_idx = city_ids.index(current_city.id) if current_city.id in city_ids else 0
        categories = get_categories()

        with st.form("shop_registration_form", clear_on_submit=False):
            st.markdown('<div class="bk-step-badge">Step 1 of 4 · Shop & Owner Details</div>', unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            with c1:
                shop_name = st.text_input("Shop / Brand Name *", placeholder="e.g., Mysuru Heritage Crafts")
                owner_name = st.text_input("Proprietor / Authorized Signatory Name *", placeholder="e.g., Ananya Rao")
                business_type = st.selectbox(
                    "Business Entity Type *",
                    options=[
                        "Sole Proprietorship",
                        "Partnership / LLP",
                        "Private Limited",
                        "Home Entrepreneur / Artisan",
                    ],
                )
            with c2:
                owner_email = st.text_input("Business Email ID *", placeholder="seller@yourshop.in")
                owner_phone = st.text_input("Registered Mobile Number (10-digit) *", placeholder="9876543210")
                primary_category = st.selectbox("Primary Selling Category *", options=categories)

            shop_description = st.text_area(
                "About Your Shop & Products (Optional)",
                placeholder="Tell buyers what makes your products special (e.g., handcrafted brassware, organic spices, custom apparel)...",
                height=75,
            )

            st.markdown("<hr style='border-color:#DFD3C3; margin: 1.1rem 0;'>", unsafe_allow_html=True)

            st.markdown('<div class="bk-step-badge">Step 2 of 4 · Tax & Regulatory KYC</div>', unsafe_allow_html=True)
            t1, t2, t3 = st.columns(3)
            with t1:
                pan_number = st.text_input("Business / Owner PAN * (10 chars)", max_chars=10, placeholder="ABCDE1234F")
            with t2:
                gstin = st.text_input(
                    "GSTIN (15 chars — Optional if exempted)",
                    max_chars=15,
                    placeholder="29ABCDE1234F1Z5",
                )
            with t3:
                fssai_license = st.text_input(
                    "FSSAI License (14 digits — Required for Groceries)",
                    max_chars=14,
                    placeholder="11223344556677",
                )

            st.markdown("<hr style='border-color:#DFD3C3; margin: 1.1rem 0;'>", unsafe_allow_html=True)

            st.markdown('<div class="bk-step-badge">Step 3 of 4 · Pickup Address & Warehouse Hub</div>', unsafe_allow_html=True)
            a1, a2, a3 = st.columns([1.3, 1, 1.3])
            with a1:
                selected_city_id = st.selectbox(
                    "Fulfillment City Hub *",
                    options=city_ids,
                    index=default_city_idx,
                    format_func=lambda cid: city_by_id[cid].label,
                )
            with a2:
                pincode = st.text_input("Shop Pincode *", max_chars=6, placeholder="560001")
            with a3:
                pickup_slot = st.selectbox(
                    "Preferred Daily Courier Pickup Slot *",
                    options=[
                        "Morning (9:00 AM – 1:00 PM)",
                        "Afternoon (1:00 PM – 5:00 PM)",
                        "Evening (5:00 PM – 9:00 PM)",
                    ],
                )

            shop_address = st.text_area(
                "Complete Shop / Warehouse Pickup Address *",
                placeholder="Shop No. 12, Ground Floor, MG Road Commercial Complex, Near Metro Station",
                height=75,
            )

            st.markdown("<hr style='border-color:#DFD3C3; margin: 1.1rem 0;'>", unsafe_allow_html=True)

            st.markdown('<div class="bk-step-badge">Step 4 of 4 · Bank Account for Payout Settlements</div>', unsafe_allow_html=True)
            bk1, bk2 = st.columns(2)
            with bk1:
                bank_account_holder = st.text_input(
                    "Account Holder / Business Name *",
                    placeholder="As per bank passbook / cancelled cheque",
                )
                bank_account_number = st.text_input(
                    "Bank Account Number *",
                    max_chars=18,
                    placeholder="50200012345678",
                )
            with bk2:
                bank_ifsc = st.text_input("IFSC Code * (11 chars)", max_chars=11, placeholder="HDFC0000184")
                upi_id = st.text_input("Business UPI ID (Optional)", placeholder="yourshop@okhdfcbank")

            agree_terms = st.checkbox(
                "I confirm that the business, tax, and bank details provided above are accurate and agree to the BharatKart Seller Agreement."
            )

            submitted = st.form_submit_button("Submit & Register Shop", type="primary", use_container_width=True)

        if submitted:
            if not agree_terms:
                st.error("Please tick the confirmation checkbox to agree to the BharatKart Seller Agreement.")
            elif primary_category == "Groceries" and not fssai_license.strip():
                st.error("**FSSAI License**: A 14-digit FSSAI license number is mandatory for shops registering under the **Groceries** category.")
            else:
                try:
                    req = ShopRegistrationRequest(
                        shop_name=shop_name,
                        owner_name=owner_name,
                        owner_email=owner_email,
                        owner_phone=owner_phone,
                        business_type=business_type,
                        primary_category=primary_category,
                        gstin=gstin,
                        pan_number=pan_number,
                        fssai_license=fssai_license,
                        city_id=selected_city_id,
                        shop_address=shop_address,
                        pincode=pincode,
                        pickup_slot=pickup_slot,
                        bank_account_holder=bank_account_holder,
                        bank_account_number=bank_account_number,
                        bank_ifsc=bank_ifsc,
                        upi_id=upi_id,
                        shop_description=shop_description,
                    )
                    created_shop = register_shop_atomic(req)
                    st.session_state.last_registered_shop = created_shop
                    st.rerun()
                except ValidationError as ve:
                    for err in ve.errors():
                        field = str(err["loc"][-1]).replace("_", " ").title() if err.get("loc") else "Field"
                        st.error(f"**{field}**: {err['msg']}")
                except ShopRegistrationError as sre:
                    st.error(str(sre))

    with tab_directory:
        st.subheader("Active Partner Shops on BharatKart")
        shops = list_registered_shops()
        st.caption(f"Total Verified Partner Shops: {len(shops)}")

        if shops:
            table_rows = [
                {
                    "Shop ID": s.shop_code,
                    "Shop Name": s.shop_name,
                    "Owner": s.owner_name,
                    "City": s.city_name,
                    "Category": s.primary_category,
                    "GSTIN": s.gstin,
                    "Pickup Slot": s.pickup_slot,
                    "Settlement A/C": f"{s.bank_account_masked} ({s.bank_ifsc})",
                    "Status": s.status,
                }
                for s in shops
            ]
            st.dataframe(pd.DataFrame(table_rows), use_container_width=True, hide_index=True)

            st.markdown("#### Shop Profile Cards")
            s_cols = st.columns(2)
            for idx, s in enumerate(shops):
                with s_cols[idx % 2]:
                    st.markdown(
                        f"""
                        <div class="bk-panel">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <span class="bk-card-brand">{s.primary_category} · {s.city_name}</span>
                                <span class="bk-stock-ok">● {s.status} ({s.shop_code})</span>
                            </div>
                            <h3 style="margin: 0.3rem 0 0.2rem 0;">{s.shop_name}</h3>
                            <div style="font-size: 0.85rem; color: #59524B; margin-bottom: 0.5rem;">
                                Proprietor: <strong>{s.owner_name}</strong> · {s.business_type}
                            </div>
                            <div style="font-size: 0.85rem; color: #22201E; margin-bottom: 0.5rem;">
                                {s.shop_description or "Verified BharatKart local merchant partner."}
                            </div>
                            <div style="font-size: 0.8rem; color: #59524B;">
                                📍 {s.shop_address} ({s.pincode})<br>
                                🚚 Pickup: {s.pickup_slot} · 🏦 Payout: {s.bank_account_masked}
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

    with tab_guide:
        st.subheader("Required Documents, Eligibility & Fee Structure")
        g1, g2 = st.columns(2, gap="large")
        with g1:
            st.markdown(
                """
                <div class="bk-panel">
                    <h3>1. Mandatory KYC Checklist</h3>
                    <ul style="line-height: 1.75; color: #22201E;">
                        <li><strong>PAN Card:</strong> Individual PAN (for Sole Proprietors) or Company/LLP PAN.</li>
                        <li><strong>GSTIN:</strong> Mandatory for interstate sales or turnover above ₹40 Lakhs (exempted intra-state small sellers can leave blank).</li>
                        <li><strong>FSSAI License (14-digit):</strong> Mandatory only if selling packaged food, coffee, tea, honey, spices, or ghee under <em>Groceries</em>.</li>
                        <li><strong>Active Bank Account:</strong> Current or Savings account with valid IFSC code for NEFT/IMPS payouts.</li>
                        <li><strong>Local Pickup Address:</strong> Shop or home studio located within Bengaluru, Mumbai, Pune, or Mangalore.</li>
                    </ul>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with g2:
            st.markdown(
                """
                <div class="bk-panel">
                    <h3>2. Commission & Settlement Policy</h3>
                    <ul style="line-height: 1.75; color: #22201E;">
                        <li><strong>Registration & Catalogue Listing:</strong> ₹0 (Completely Free).</li>
                        <li><strong>Marketplace Commission:</strong> Flat <strong>5%</strong> across Electronics, Fashion, Home & Kitchen, Groceries, and Personal Care.</li>
                        <li><strong>Payment Gateway Fee:</strong> 0% extra (included in platform fee).</li>
                        <li><strong>Settlement Cycle:</strong> T+2 business days post-delivery directly to your registered bank account.</li>
                        <li><strong>Hyperlocal Delivery Support:</strong> BharatKart courier partners pick up packed orders during your chosen daily time slot.</li>
                    </ul>
                </div>
                """,
                unsafe_allow_html=True,
            )
