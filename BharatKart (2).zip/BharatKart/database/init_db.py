import logging
from backend.database import Base, engine, get_db_session
from backend import models  # noqa: F401
from database.seed_data import seed_initial_data

logger = logging.getLogger(__name__)


def initialize_database() -> None:
    Base.metadata.create_all(bind=engine)
    with get_db_session() as session:
        seed_initial_data(session)
