import logging
from sqlalchemy import select
from backend.database import get_db_session
from backend.models import City, Customer
from backend.schemas import CustomerDTO, CustomerRegistrationRequest

logger = logging.getLogger(__name__)


class CustomerRegistrationError(Exception):
    pass


def register_or_update_customer(req: CustomerRegistrationRequest) -> CustomerDTO:
    try:
        with get_db_session() as session:
            city = session.execute(
                select(City).where(City.id == req.default_city_id, City.is_active.is_(True))
            ).scalar_one_or_none()
            if not city:
                raise CustomerRegistrationError("Selected default city is invalid.")

            existing = session.execute(select(Customer).where(Customer.email == req.email)).scalar_one_or_none()
            if existing:
                existing.full_name = req.full_name
                existing.phone = req.phone
                existing.default_city_id = city.id
                existing.default_address = req.default_address
                existing.pincode = req.pincode
                customer = existing
            else:
                customer = Customer(
                    full_name=req.full_name,
                    email=req.email,
                    phone=req.phone,
                    default_city_id=city.id,
                    default_address=req.default_address,
                    pincode=req.pincode,
                )
                session.add(customer)

            session.flush()
            return CustomerDTO(
                id=customer.id,
                full_name=customer.full_name,
                email=customer.email,
                phone=customer.phone,
                default_city_id=city.id,
                city_name=f"{city.name}, {city.state}",
                default_address=customer.default_address,
                pincode=customer.pincode,
            )
    except CustomerRegistrationError:
        raise
    except Exception as exc:
        logger.exception("Error registering customer")
        raise CustomerRegistrationError("Unable to save customer profile right now.") from exc
