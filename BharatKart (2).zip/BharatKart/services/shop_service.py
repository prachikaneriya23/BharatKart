import json
import logging
import uuid
from sqlalchemy import desc, select
from backend.database import get_db_session
from backend.models import City, OutboxEvent, Shop
from backend.schemas import ShopDTO, ShopRegistrationRequest
from utils.helpers import generate_shop_code

logger = logging.getLogger(__name__)


class ShopRegistrationError(Exception):
    pass


def _mask_account(acc: str) -> str:
    if len(acc) <= 4:
        return acc
    return "•" * (len(acc) - 4) + acc[-4:]


def _to_shop_dto(shop: Shop, city: City) -> ShopDTO:
    return ShopDTO(
        id=shop.id,
        shop_code=shop.shop_code,
        shop_name=shop.shop_name,
        owner_name=shop.owner_name,
        owner_email=shop.owner_email,
        owner_phone=shop.owner_phone,
        business_type=shop.business_type,
        primary_category=shop.primary_category,
        gstin=shop.gstin or "Unregistered / Exempted",
        pan_number=shop.pan_number,
        fssai_license=shop.fssai_license or "Not Applicable",
        city_id=city.id,
        city_name=f"{city.name}, {city.state}",
        shop_address=shop.shop_address,
        pincode=shop.pincode,
        pickup_slot=shop.pickup_slot,
        bank_account_holder=shop.bank_account_holder,
        bank_account_masked=_mask_account(shop.bank_account_number),
        bank_ifsc=shop.bank_ifsc,
        upi_id=shop.upi_id or "—",
        shop_description=shop.shop_description or "",
        status=shop.status,
        created_at=shop.created_at,
    )


def register_shop_atomic(req: ShopRegistrationRequest) -> ShopDTO:
    try:
        with get_db_session() as session:
            city = session.execute(
                select(City).where(City.id == req.city_id, City.is_active.is_(True))
            ).scalar_one_or_none()
            if not city:
                raise ShopRegistrationError("Selected city hub is invalid or inactive.")

            duplicate = session.execute(
                select(Shop).where(Shop.shop_name.ilike(req.shop_name), Shop.city_id == city.id)
            ).scalar_one_or_none()
            if duplicate:
                raise ShopRegistrationError(
                    f"A shop named '{duplicate.shop_name}' is already registered in {city.name} (ID: {duplicate.shop_code})."
                )

            shop = Shop(
                shop_code=generate_shop_code(),
                shop_name=req.shop_name,
                owner_name=req.owner_name,
                owner_email=req.owner_email,
                owner_phone=req.owner_phone,
                business_type=req.business_type,
                primary_category=req.primary_category,
                gstin=req.gstin or None,
                pan_number=req.pan_number,
                fssai_license=req.fssai_license or None,
                city_id=city.id,
                shop_address=req.shop_address,
                pincode=req.pincode,
                pickup_slot=req.pickup_slot,
                bank_account_holder=req.bank_account_holder,
                bank_account_number=req.bank_account_number,
                bank_ifsc=req.bank_ifsc,
                upi_id=req.upi_id.strip() if req.upi_id else None,
                shop_description=req.shop_description.strip() if req.shop_description else None,
                status="VERIFIED",
            )
            session.add(shop)
            session.flush()

            event_id = f"evt-{uuid.uuid4().hex}"
            payload = {
                "event_id": event_id,
                "event_type": "ShopRegistered",
                "shop_id": shop.id,
                "shop_code": shop.shop_code,
                "shop_name": shop.shop_name,
                "city_code": city.code,
                "primary_category": shop.primary_category,
            }
            session.add(
                OutboxEvent(
                    event_id=event_id,
                    aggregate_type="Shop",
                    aggregate_id=str(shop.id),
                    event_type="ShopRegistered",
                    payload=json.dumps(payload),
                    status="PENDING",
                )
            )
            session.flush()
            return _to_shop_dto(shop, city)
    except ShopRegistrationError:
        raise
    except Exception as exc:
        logger.exception("Unexpected error registering partner shop")
        raise ShopRegistrationError("Unable to complete shop registration right now. Please try again.") from exc


def list_registered_shops(city_id: int | None = None) -> list[ShopDTO]:
    with get_db_session() as session:
        stmt = select(Shop, City).join(City, City.id == Shop.city_id).order_by(desc(Shop.created_at))
        if city_id is not None:
            stmt = stmt.where(Shop.city_id == city_id)
        rows = session.execute(stmt).all()
        return [_to_shop_dto(shop, city) for shop, city in rows]
