from decimal import Decimal
from typing import List, Optional
from sqlalchemy import asc, desc, or_, select
import streamlit as st
from backend.database import get_db_session
from backend.models import City, Inventory, Product
from backend.schemas import CityDTO, ProductCardDTO
from utils.helpers import get_product_photo_url


def _to_product_dto(product: Product, inv: Inventory, city: City) -> ProductCardDTO:
    discount = 0
    if product.mrp and product.mrp > 0 and product.mrp > product.price:
        discount = int(round(((product.mrp - product.price) / product.mrp) * 100))

    img = product.image_url or ""
    if not img.startswith("https://"):
        img = get_product_photo_url(product.sku)

    return ProductCardDTO(
        id=product.id,
        sku=product.sku,
        name=product.name,
        brand=product.brand,
        category=product.category,
        description=product.description,
        image_url=img,
        price=Decimal(product.price),
        mrp=Decimal(product.mrp),
        discount_percent=discount,
        rating=Decimal(product.rating),
        is_featured=product.is_featured,
        city_id=city.id,
        city_name=f"{city.name}, {city.state}",
        stock_quantity=inv.stock_quantity,
    )


@st.cache_data(ttl=60, show_spinner=False)
def get_active_cities() -> List[CityDTO]:
    with get_db_session() as session:
        rows = session.execute(select(City).where(City.is_active.is_(True)).order_by(City.id)).scalars().all()
        return [CityDTO(id=c.id, name=c.name, state=c.state, code=c.code) for c in rows]


@st.cache_data(ttl=60, show_spinner=False)
def get_categories() -> List[str]:
    with get_db_session() as session:
        rows = session.execute(select(Product.category).distinct().order_by(Product.category)).scalars().all()
        return list(rows)


def list_products_for_city(
    city_id: int,
    search_query: str = "",
    category: str = "All",
    sort_by: str = "Featured",
    only_featured: bool = False,
    in_stock_only: bool = False,
) -> List[ProductCardDTO]:
    with get_db_session() as session:
        stmt = (
            select(Product, Inventory, City)
            .join(Inventory, Inventory.product_id == Product.id)
            .join(City, City.id == Inventory.city_id)
            .where(City.id == city_id)
        )

        if only_featured:
            stmt = stmt.where(Product.is_featured.is_(True))
        if category and category != "All":
            stmt = stmt.where(Product.category == category)
        if in_stock_only:
            stmt = stmt.where(Inventory.stock_quantity > 0)
        if search_query and search_query.strip():
            term = f"%{search_query.strip()}%"
            stmt = stmt.where(
                or_(
                    Product.name.ilike(term),
                    Product.brand.ilike(term),
                    Product.category.ilike(term),
                    Product.description.ilike(term),
                )
            )

        if sort_by == "Price: Low to High":
            stmt = stmt.order_by(asc(Product.price))
        elif sort_by == "Price: High to Low":
            stmt = stmt.order_by(desc(Product.price))
        elif sort_by == "Top Rated":
            stmt = stmt.order_by(desc(Product.rating))
        elif sort_by == "Availability":
            stmt = stmt.order_by(desc(Inventory.stock_quantity), desc(Product.is_featured))
        else:
            stmt = stmt.order_by(desc(Product.is_featured), asc(Product.id))

        results = session.execute(stmt).all()
        return [_to_product_dto(prod, inv, city) for prod, inv, city in results]


def get_product_detail(product_id: int, city_id: int) -> Optional[ProductCardDTO]:
    with get_db_session() as session:
        row = session.execute(
            select(Product, Inventory, City)
            .join(Inventory, Inventory.product_id == Product.id)
            .join(City, City.id == Inventory.city_id)
            .where(Product.id == product_id, City.id == city_id)
        ).first()
        if not row:
            return None
        return _to_product_dto(row[0], row[1], row[2])


def refresh_cart_snapshot(city_id: int, cart_items: dict[int, int]) -> tuple[list[dict], list[str]]:
    if not cart_items:
        return [], []
    warnings: list[str] = []
    lines: list[dict] = []
    with get_db_session() as session:
        product_ids = [int(pid) for pid in cart_items.keys()]
        rows = session.execute(
            select(Product, Inventory)
            .join(Inventory, Inventory.product_id == Product.id)
            .where(Inventory.city_id == city_id, Product.id.in_(product_ids))
        ).all()
        lookup = {prod.id: (prod, inv) for prod, inv in rows}

        for pid_raw, requested_qty in list(cart_items.items()):
            pid = int(pid_raw)
            if pid not in lookup:
                warnings.append(f"Removed unavailable product ID {pid} from cart.")
                continue
            prod, inv = lookup[pid]
            if inv.stock_quantity <= 0:
                warnings.append(f"'{prod.name}' is now out of stock in your selected city.")
                continue
            final_qty = min(int(requested_qty), inv.stock_quantity)
            if final_qty < int(requested_qty):
                warnings.append(
                    f"Adjusted '{prod.name}' quantity from {requested_qty} to {final_qty} due to live stock limits."
                )
            unit_price = Decimal(prod.price)
            img = prod.image_url if (prod.image_url and prod.image_url.startswith("https://")) else get_product_photo_url(prod.sku)
            lines.append(
                {
                    "product_id": prod.id,
                    "sku": prod.sku,
                    "name": prod.name,
                    "brand": prod.brand,
                    "image_url": img,
                    "unit_price": unit_price,
                    "mrp": Decimal(prod.mrp),
                    "quantity": final_qty,
                    "stock_quantity": inv.stock_quantity,
                    "line_total": unit_price * final_qty,
                }
            )
    return lines, warnings
